package com.djaeger.controlcenter

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import java.util.concurrent.Executors

data class Telemetry(val epoch:Long=0,val cpuT:Int=0,val gpuT:Int=0,val skinT:Int=0,val batT:Int=0,val littleKhz:Long=0,val bigKhz:Long=0,val gpuHz:Long=0,val profile:String="NA",val frameMs:Double=0.0,val fps:Double=0.0,val jank:Double=0.0,val p95:Double=0.0,val p99:Double=0.0,val batteryStatus:String="NA",val currentUa:Long=0,val voltageUv:Long=0,val powerMw:Double=0.0,val powerValid:String="NA",val powerReason:String="NA",val windowMode:String="INACTIVE")
data class DecisionRecord(val id:String,val game:String,val scene:String,val profile:String,val little:String,val big:String,val gpu:String,val predSkin:String,val predFps:String,val outcome:String,val actualSkin:String,val actualFps:String,val window:String)
data class PlanRecord(val state:String,val score:String,val reason:String,val mode:String,val profile:String,val lmin:String,val lmax:String,val bmin:String,val bmax:String,val gmin:String,val gmax:String)
data class RuntimeState(val root:Boolean=false,val sampleFresh:Boolean=false,val installed:Boolean=false,val active:String="0",val game:String="NA",val window:String="INACTIVE",val controllerPid:String="",val predictorPid:String="",val updated:Long=0,val moduleVersion:String="unknown",val telemetry:Telemetry=Telemetry(),val brain:String="",val envelope:String="",val geminiHttp:String="",val geminiServer:String="",val decisions:String="",val plans:String="",val frameIntel:String="",val log:String="",val latestDecision:DecisionRecord?=null,val latestPlan:PlanRecord?=null,val error:String="")

class DjaegerRepository {
    private val module="/data/adb/modules/djaeger_game_stabilizer"; private val persistent="/data/adb/djaeger_ai"
    private fun su(command:String):Pair<Int,String> {
        val readerExecutor=Executors.newSingleThreadExecutor()
        return try {
            val p=ProcessBuilder("su","-c",command).redirectErrorStream(true).start()
            val outputFuture=readerExecutor.submit<String> { p.inputStream.bufferedReader().use { it.readText() } }
            if(!p.waitFor(2500,TimeUnit.MILLISECONDS)){
                p.destroy(); if(p.isAlive)p.destroyForcibly()
                outputFuture.cancel(true)
                Pair(-2,"Root request timed out after 2.5s")
            } else {
                val output=try{ outputFuture.get(300,TimeUnit.MILLISECONDS) }catch(_:Exception){ "" }
                Pair(p.exitValue(),output)
            }
        } catch(e:Exception){ Pair(-1,e.message?:"root execution failed") }
        finally { readerExecutor.shutdownNow() }
    }
    suspend fun snapshot():RuntimeState=withContext(Dispatchers.IO){ val result=su("""
        echo __INSTALLED__; [ -d '$module' ] && echo 1 || echo 0
        echo __VERSION__; sed -n 's/^version=//p' '$module/module.prop' 2>/dev/null | head -n 1
        echo __RUNTIME__; cat '$persistent/runtime_status' 2>/dev/null
        echo __TEL__; tail -n 1 '$module/telemetry.csv' 2>/dev/null
        echo __BRAIN__; cat '$persistent/local_brain_state' 2>/dev/null
        echo __ENV__; cat '$persistent/adaptive_operating_envelope' 2>/dev/null
        echo __HTTP__; cat '$persistent/gemini_http_state' 2>/dev/null
        echo __SERVER__; cat '$persistent/gemini_server_state' 2>/dev/null
        echo __DECISIONS__; tail -n 16 '$persistent/decision_ledger.csv' 2>/dev/null
        echo __PLANS__; tail -n 16 '$persistent/plan_history.csv' 2>/dev/null
        echo __FRAME__; tail -n 30 '$module/frame_intel.csv' 2>/dev/null
        echo __LOG__; tail -n 120 '$module/controller.log' 2>/dev/null
    """.trimIndent())
        val(rc,out)=result; if(rc!=0)return@withContext RuntimeState(error=out.ifBlank{"Root permission unavailable"});fun section(a:String,b:String?):String{val s=out.substringAfter("__$a__\n","");return if(b==null)s else s.substringBefore("__$b__\n","")};val installed=section("INSTALLED","VERSION").trim()=="1";val moduleVersion=section("VERSION","RUNTIME").trim().ifBlank{"unknown"};val rt=section("RUNTIME","TEL").lineSequence().mapNotNull{l->l.split("=",limit=2).takeIf{it.size==2}?.let{it[0] to it[1].trim().trim('\'')}}.toMap();val decisions=section("DECISIONS","PLANS").trim();val plans=section("PLANS","FRAME").trim();val tel=parseTelemetry(section("TEL","BRAIN").trim()); val now=System.currentTimeMillis()/1000; val age=now-tel.epoch; RuntimeState(root=true,sampleFresh=tel.epoch>0 && age in 0..5,installed=installed,active=rt["active"]?:"0",game=rt["game"]?:"NA",window=rt["window_mode"]?:"INACTIVE",controllerPid=rt["controller_pid"]?:"",predictorPid=rt["predictor_pid"]?:"",updated=rt["updated_at"]?.toLongOrNull()?:0,moduleVersion=moduleVersion,telemetry=tel,brain=section("BRAIN","ENV").trim(),envelope=section("ENV","HTTP").trim(),geminiHttp=section("HTTP","SERVER").trim(),geminiServer=section("SERVER","DECISIONS").trim(),decisions=decisions,plans=plans,frameIntel=section("FRAME","LOG").trim(),log=section("LOG",null).trim(),latestDecision=parseDecision(decisions),latestPlan=parsePlan(plans))}
    private fun parseTelemetry(line:String):Telemetry{val c=parseCsv(line);fun s(i:Int)=c.getOrNull(i)?.trim().orEmpty();return Telemetry(s(0).toLongOrNull()?:0,s(1).toIntOrNull()?:0,s(2).toIntOrNull()?:0,s(3).toIntOrNull()?:0,s(4).toIntOrNull()?:0,s(5).toLongOrNull()?:0,s(6).toLongOrNull()?:0,s(7).toLongOrNull()?:0,s(8),s(9).toDoubleOrNull()?:0.0,s(10).toDoubleOrNull()?:0.0,s(11).toDoubleOrNull()?:0.0,s(12).toDoubleOrNull()?:0.0,s(13).toDoubleOrNull()?:0.0,s(15),s(16).toLongOrNull()?:0,s(17).toLongOrNull()?:0,s(18).toDoubleOrNull()?:0.0,s(19),s(20),s(22))}
    private fun parseDecision(text:String):DecisionRecord?{val l=text.lineSequence().filter{it.isNotBlank()&&!it.startsWith("decision_id,")}.lastOrNull()?:return null;val c=parseCsv(l);if(c.size<18)return null;return DecisionRecord(c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[8],c[9],c[10],c[11],c[12],c[17])}
    private fun parsePlan(text:String):PlanRecord?{val l=text.lineSequence().filter{it.isNotBlank()&&!it.startsWith("epoch,")}.lastOrNull()?:return null;val c=parseCsv(l);if(c.size<12)return null;return PlanRecord(c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9],c[10],c[11])}
    private fun parseCsv(line:String):List<String>{
        val out=mutableListOf<String>(); val cell=StringBuilder(); var quoted=false; var i=0
        while(i<line.length){ val ch=line[i]; when {
            ch=='"' -> if(quoted && i+1<line.length && line[i+1]=='"'){cell.append('"');i++} else quoted=!quoted
            ch==',' && !quoted -> {out.add(cell.toString().trim());cell.clear()}
            else -> cell.append(ch)
        }; i++ }; out.add(cell.toString().trim()); return out
    }

}
