package com.djaeger.controlcenter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App()}} }
private val Bg=Color(0xFF090B10); private val Card=Color(0xFF121722); private val Green=Color(0xFF43E38A); private val Muted=Color(0xFF98A2B3); private val Amber=Color(0xFFFFC857); private val Red=Color(0xFFFF6B6B)

data class Sample(val fps:Double,val frame:Double,val cpu:Float,val gpu:Float,val skin:Float,val bat:Float)

@Composable fun App(){ val repo=remember{DjaegerRepository()}; var state by remember{mutableStateOf(RuntimeState())}; var tab by remember{mutableIntStateOf(0)}; val samples=remember{mutableStateListOf<Sample>()}
    val lifecycleOwner=LocalLifecycleOwner.current; LaunchedEffect(lifecycleOwner){lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED){ var lastEpoch=0L; while(true){state=repo.snapshot(); if(state.root&&state.installed&&state.sampleFresh&&state.telemetry.epoch>lastEpoch){with(state.telemetry){samples.add(Sample(fps,frameMs,cpuT.toFloat(),gpuT.toFloat(),skinT.toFloat(),batT.toFloat()));lastEpoch=epoch;while(samples.size>60)samples.removeAt(0)}};delay(1000)}}}
    MaterialTheme(colorScheme=darkColorScheme(primary=Green,background=Bg,surface=Card)){Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)){Text("DJAEGER",fontWeight=FontWeight.Black,style=MaterialTheme.typography.headlineMedium);Text("CONTROL CENTER • v0.5.3 RC • REGRESSION VALIDATED",color=Muted);Spacer(Modifier.height(12.dp));ScrollableTabRow(selectedTabIndex=tab,containerColor=Bg,edgePadding=0.dp){listOf("Overview","Session","Charts","AI","History","Safety","Logs").forEachIndexed{i,n->Tab(selected=tab==i,onClick={tab=i},text={Text(n)})}};Spacer(Modifier.height(12.dp));when(tab){0->Overview(state);1->Session(state,samples);2->Charts(state,samples);3->AI(state);4->History(state);5->Safety(state);else->Logs(state)}}}}

@Composable fun Overview(s:RuntimeState){Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){if(s.error.isNotBlank())BoxCard("ROOT / CONNECTION",s.error);StatusCard(s);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Metric("FPS","%.1f".format(s.telemetry.fps),Modifier.weight(1f));Metric("Frame","%.1f ms".format(s.telemetry.frameMs),Modifier.weight(1f));Metric("Jank","%.1f%%".format(s.telemetry.jank),Modifier.weight(1f))};ThermalRow(s);BoxCard("PERFORMANCE","Little: ${s.telemetry.littleKhz/1000} MHz\nBig: ${s.telemetry.bigKhz/1000} MHz\nGPU: ${s.telemetry.gpuHz/1_000_000} MHz\nProfile: ${s.telemetry.profile}\nP95/P99: ${s.telemetry.p95} / ${s.telemetry.p99} ms");BoxCard("POWER","${s.telemetry.batteryStatus} • %.1f mW".format(s.telemetry.powerMw)+"\n${s.telemetry.currentUa} µA • ${s.telemetry.voltageUv} µV\nValidity: ${s.telemetry.powerValid} (${s.telemetry.powerReason})");BoxCard("FRAME INTELLIGENCE • RECENT",s.frameIntel.ifBlank{"No frame history yet"},true)}}
@Composable fun StatusCard(s:RuntimeState){val stale=s.updated>0&&(System.currentTimeMillis()/1000-s.updated)>5; val session=if(s.telemetry.epoch>0) SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(Date(s.telemetry.epoch*1000)) else "—"; BoxCard("ENGINE / SESSION",if(s.installed)"${if(s.active=="1")"● ACTIVE" else "○ IDLE"} • ${if(stale)"STALE" else "LIVE"}\nModule: ${s.moduleVersion}\nGame: ${s.game}\nWindow: ${s.window}\nProfile: ${s.telemetry.profile}\nLast sample: $session\nController PID: ${s.controllerPid.ifBlank{"—"}} • Predictor PID: ${s.predictorPid.ifBlank{"—"}}" else "DJAEGER module not found")}
@Composable fun ThermalRow(s:RuntimeState){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Thermal("CPU",s.telemetry.cpuT,Modifier.weight(1f));Thermal("GPU",s.telemetry.gpuT,Modifier.weight(1f));Thermal("Skin",s.telemetry.skinT,Modifier.weight(1f));Thermal("Battery",s.telemetry.batT,Modifier.weight(1f))}}
@Composable fun Thermal(label:String,t:Int,m:Modifier){val c=when{t>=50->Red;t>=43->Amber;else->Green};Card(m,colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(12.dp)){Text(label,color=Muted,style=MaterialTheme.typography.labelMedium);Text("$t°C",color=c,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium)}}}


@Composable fun Session(s:RuntimeState,samples:List<Sample>){
    fun avg(v:List<Double>)=if(v.isEmpty())0.0 else v.average()
    val fps=samples.map{it.fps}; val frame=samples.map{it.frame}; val cpu=samples.map{it.cpu.toDouble()}; val gpu=samples.map{it.gpu.toDouble()}; val skin=samples.map{it.skin.toDouble()}
    val phase=monitorPhase(s)
    val anomalies=anomalySummary(s,samples)
    Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){
        BoxCard("MONITOR SESSION","Samples: ${samples.size} / 60\nWindow: ${s.window} • Game: ${s.game}\nObserved phase: $phase\nThis phase is a monitor-side interpretation, not a command to DJAEGER.")
        BoxCard("60-SECOND STATISTICS","FPS avg/min/max: %.1f / %.1f / %.1f\nFrame avg/max: %.1f / %.1f ms\nCPU avg/peak: %.1f / %.1f°C\nGPU avg/peak: %.1f / %.1f°C\nSkin avg/peak: %.1f / %.1f°C".format(avg(fps),fps.minOrNull()?:0.0,fps.maxOrNull()?:0.0,avg(frame),frame.maxOrNull()?:0.0,avg(cpu),cpu.maxOrNull()?:0.0,avg(gpu),gpu.maxOrNull()?:0.0,avg(skin),skin.maxOrNull()?:0.0))
        BoxCard("ANOMALY WATCH",anomalies)
        BoxCard("CURRENT INTERPRETATION",humanDecision(s))
    }
}
private fun monitorPhase(s:RuntimeState):String{
    val text=(s.brain+" "+s.envelope+" "+s.latestDecision?.outcome.orEmpty()).lowercase()
    return when{
        s.active!="1"||s.window.equals("INACTIVE",true)->"IDLE / RESTORED WINDOW"
        "recover" in text||"cool" in text->"RECOVERY / THERMAL RELIEF"
        "thermal" in text||s.telemetry.skinT>=45||s.telemetry.cpuT>=55->"THERMAL INTERVENTION LIKELY"
        "boost" in text||"ramp" in text->"PERFORMANCE RAMP / BOOST LIKELY"
        else->"HOLD / ADAPTIVE CONTROL"
    }
}
private fun anomalySummary(s:RuntimeState,samples:List<Sample>):String{
    val a=mutableListOf<String>(); val now=System.currentTimeMillis()/1000
    if(!s.root)a.add("Root unavailable")
    if(!s.installed)a.add("DJAEGER module not found")
    if(s.updated>0&&now-s.updated>5)a.add("Runtime status stale (${now-s.updated}s)")
    if(s.active=="1"&&s.controllerPid.isBlank())a.add("Active session without reported controller PID")
    if(s.telemetry.powerValid.equals("0")||s.telemetry.powerValid.equals("false",true))a.add("Battery power telemetry invalid: ${s.telemetry.powerReason}")
    if(s.telemetry.skinT>=48)a.add("High skin temperature: ${s.telemetry.skinT}°C")
    if(s.telemetry.cpuT>=60)a.add("High CPU temperature: ${s.telemetry.cpuT}°C")
    if(samples.size>=10){val recent=samples.takeLast(10); val avg=recent.map{it.fps}.average(); if(avg>0&&recent.last().fps<avg*0.70)a.add("FPS dropped >30% versus recent 10s average") }
    return if(a.isEmpty())"No monitor-side anomaly detected in the current snapshot." else a.joinToString("\n") { "• $it" }
}
private fun humanDecision(s:RuntimeState):String{
    val d=s.latestDecision; val p=s.latestPlan
    if(d==null&&p==null)return "No structured decision/plan is available yet. Raw DJAEGER state remains visible in AI and History."
    val outcome=d?.outcome?.ifBlank{"not reported"}?:"not reported"
    return "DJAEGER is publishing profile ${d?.profile?:p?.profile?:s.telemetry.profile}. Latest recorded outcome: $outcome. Current monitor interpretation: ${monitorPhase(s)}. Thermal and restoration authority remain inside DJAEGER; this screen only explains published state."
}

@Composable fun Charts(s:RuntimeState,samples:List<Sample>){Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){BoxCard("LIVE WINDOW","Last ${samples.size} seconds • refresh 1s\nCharts are display-only; DJAEGER remains control authority.");LineChartCard("FPS",samples.map{it.fps.toFloat()},0f,120f,"%.1f".format(s.telemetry.fps));LineChartCard("FRAME TIME",samples.map{it.frame.toFloat()},0f,50f,"%.1f ms".format(s.telemetry.frameMs));LineChartCard("CPU TEMPERATURE",samples.map{it.cpu},20f,70f,"${s.telemetry.cpuT}°C");LineChartCard("GPU TEMPERATURE",samples.map{it.gpu},20f,70f,"${s.telemetry.gpuT}°C");LineChartCard("SKIN TEMPERATURE",samples.map{it.skin},20f,55f,"${s.telemetry.skinT}°C")}}
@Composable fun LineChartCard(title:String,values:List<Float>,min:Float,max:Float,current:String){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(14.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(title,color=Green,fontWeight=FontWeight.Bold);Text(current,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(10.dp));Canvas(Modifier.fillMaxWidth().height(120.dp)){if(values.size>1){val lo=min;val hi=max.coerceAtLeast(lo+1);val step=size.width/(values.size-1);fun y(v:Float)=size.height-(v.coerceIn(lo,hi)-lo)/(hi-lo)*size.height;for(i in 1 until values.size)drawLine(color=Green,start=Offset((i-1)*step,y(values[i-1])),end=Offset(i*step,y(values[i])),strokeWidth=3f)}}}}}

@Composable fun AI(s:RuntimeState){Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){BoxCard("AI SUMMARY",aiSummary(s));BoxCard("LOCAL BRAIN",s.brain.ifBlank{"No state published yet"});BoxCard("ADAPTIVE OPERATING ENVELOPE",s.envelope.ifBlank{"No envelope published yet"});BoxCard("GEMINI HTTP STATE",s.geminiHttp.ifBlank{"No Gemini HTTP state yet"},true);BoxCard("GEMINI SERVER STATE",s.geminiServer.ifBlank{"No server state / no active backoff"},true)}}
private fun aiSummary(s:RuntimeState):String{val h=s.geminiHttp.lowercase();val server=s.geminiServer.lowercase();val gem=when{h.isBlank()&&server.isBlank()->"No published Gemini state";"backoff" in server||"error" in h||"fail" in h->"Attention / fallback state reported";else->"State published"};return "Local brain: ${if(s.brain.isBlank())"not published" else "available"}\nEnvelope: ${if(s.envelope.isBlank())"not published" else "available"}\nGemini: $gem\nAuthority: advisory only"}
@Composable fun History(s:RuntimeState){Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){DecisionCard(s.latestDecision);PlanCard(s.latestPlan);BoxCard("DECISION LEDGER • LAST 16",s.decisions.ifBlank{"No decisions recorded yet"},true);BoxCard("PLAN HISTORY • LAST 16",s.plans.ifBlank{"No plans recorded yet"},true)}}
@Composable fun DecisionCard(d:DecisionRecord?){if(d==null)BoxCard("LATEST AI DECISION","No decision parsed yet") else BoxCard("LATEST AI DECISION","ID: ${d.id}\nGame: ${d.game} • Scene: ${d.scene}\nProfile: ${d.profile}\nBudgets L/B/G: ${d.little} / ${d.big} / ${d.gpu}\nOutcome: ${d.outcome}\nPred FPS/Skin: ${d.predFps} / ${d.predSkin}\nActual FPS/Skin: ${d.actualFps} / ${d.actualSkin}\nWindow: ${d.window}")}
@Composable fun PlanCard(p:PlanRecord?){if(p==null)BoxCard("LATEST PLAN","No plan parsed yet") else BoxCard("LATEST PLAN","State: ${p.state} • Score: ${p.score}\nReason: ${p.reason}\nMode/Profile: ${p.mode} / ${p.profile}\nLittle: ${p.lmin}–${p.lmax}\nBig: ${p.bmin}–${p.bmax}\nGPU: ${p.gmin}–${p.gmax}")}
@Composable fun Safety(s:RuntimeState){val stale=s.updated>0&&(System.currentTimeMillis()/1000-s.updated)>5;Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){BoxCard("MONITOR INVARIANTS","READ-ONLY application\nNo direct sysfs writes\nNo network/game traffic manipulation\nLocal/native thermal authority preserved\nGemini remains advisory only");BoxCard("RUNTIME HEALTH","Root: ${if(s.root)"OK" else "UNAVAILABLE"}\nModule: ${if(s.installed)"FOUND" else "NOT FOUND"}\nController: ${if(s.controllerPid.isNotBlank())"PID ${s.controllerPid}" else "NOT REPORTED"}\nPredictor: ${if(s.predictorPid.isNotBlank())"PID ${s.predictorPid}" else "NOT REPORTED"}\nRuntime status: ${if(stale)"STALE >5s" else "FRESH"}\nPower telemetry: ${s.telemetry.powerValid} (${s.telemetry.powerReason})");BoxCard("RESTORATION WATCH","Control Center does not alter CPU/GPU state. Original-state restoration remains owned by DJAEGER controller lifecycle and its fail-safe paths.")}}
@Composable fun Logs(s:RuntimeState){Column(Modifier.verticalScroll(rememberScrollState())){BoxCard("LIVE CONTROLLER LOG • LAST 120",s.log.ifBlank{"No controller log available"},true)}}
@Composable fun Metric(label:String,value:String,m:Modifier=Modifier){Card(m,colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(12.dp)){Text(label,color=Muted,style=MaterialTheme.typography.labelMedium);Text(value,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium)}}}
@Composable fun BoxCard(title:String,text:String,mono:Boolean=false){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(14.dp)){Text(title,color=Green,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.labelLarge);Spacer(Modifier.height(7.dp));Text(text,color=Color(0xFFE6EAF0),fontFamily=if(mono)FontFamily.Monospace else FontFamily.Default,style=MaterialTheme.typography.bodyMedium)}}}
