plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.djaeger.controlcenter"; compileSdk = 35
    defaultConfig { applicationId = "com.djaeger.controlcenter"; minSdk = 26; targetSdk = 35; versionCode = 8; versionName = "0.5.3-rc-cogo" }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.10" }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
