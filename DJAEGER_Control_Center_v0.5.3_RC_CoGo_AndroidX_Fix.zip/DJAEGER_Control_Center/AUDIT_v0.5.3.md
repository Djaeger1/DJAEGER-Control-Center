# DJAEGER Control Center v0.5.3 RC — Regression Validation

Baseline module: DJAEGER Autonomous Control Plane v12.9.20 Mature Resource Intelligence.

## Verified source contracts
- telemetry.csv header in controller.sh: 24 columns; app consumes epoch, temperatures, current clocks, profile, frame/FPS/jank/P95/P99, battery power validity, and window_mode at their source-defined positions.
- decision_ledger.csv header in predictor.sh: 18 columns; latest structured decision requires >=18 columns.
- plan_history.csv header in controller.sh: 12 columns; latest structured plan requires >=12 columns.
- runtime_status contains controller_pid, predictor_pid, active, game, window_mode, updated_at.

## Regression tests
`tools/ParserRegression.kt` was compiled and executed with local kotlinc. Tests cover exact column counts, quoted commas, escaped quotes, plan parsing assumptions, and telemetry freshness boundaries including future timestamp rejection. See `REGRESSION_RESULTS_v0.5.3.txt`.

## Safety audit
Production source was scanned for sysfs/network/package/process control patterns. No hardware/network write path was added. The only root process invocation remains the fixed read-only snapshot command. Manifest declares no INTERNET permission and no other uses-permission entries.

## Build status
Android APK compilation is still unverified because this environment has no Android SDK/Gradle Android build toolchain. v0.5.3 is therefore an RC source candidate, not an installable APK.
