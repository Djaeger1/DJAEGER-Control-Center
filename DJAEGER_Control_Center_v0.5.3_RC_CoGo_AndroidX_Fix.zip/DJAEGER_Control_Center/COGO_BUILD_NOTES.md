# Code on the Go build adaptation

This package changes only the Android build toolchain configuration for on-device Code on the Go builds.

- AGP: 8.11.0
- Kotlin Gradle plugin: 1.9.22
- Compose compiler extension: 1.5.10
- JVM target: 17
- Application monitoring/runtime source is unchanged from v0.5.3 RC.
- No INTERNET permission added.
- No DJAEGER controller/sysfs/network write path added.

## AndroidX build fix
Added gradle.properties for Code on the Go build compatibility:
- android.useAndroidX=true
- android.enableJetifier=true
This changes build configuration only; application monitoring logic is unchanged.
