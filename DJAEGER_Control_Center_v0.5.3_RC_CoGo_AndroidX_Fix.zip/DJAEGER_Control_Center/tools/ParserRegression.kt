private fun parseCsv(line:String):List<String>{
    val out=mutableListOf<String>(); val cell=StringBuilder(); var quoted=false; var i=0
    while(i<line.length){ val ch=line[i]; when {
        ch=='"' -> if(quoted && i+1<line.length && line[i+1]=='"'){cell.append('"');i++} else quoted=!quoted
        ch==',' && !quoted -> {out.add(cell.toString().trim());cell.clear()}
        else -> cell.append(ch)
    }; i++ }; out.add(cell.toString().trim()); return out
}
private fun requireEq(name:String, actual:Any?, expected:Any?){
    if(actual!=expected) error("$name expected=$expected actual=$actual")
    println("PASS $name")
}
fun main(){
    val telemetry="1770000000,48,46,39,37,1209600,1804800,650000000,STABLE,16.7,59.9,1.2,18.4,23.1,120,Discharging,-450000,3900000,1755.0,VALID,OK,1.0,ACTIVE,1769999900"
    val t=parseCsv(telemetry)
    requireEq("telemetry column count",t.size,24)
    requireEq("telemetry profile",t[8],"STABLE")
    requireEq("telemetry window_mode",t[22],"ACTIVE")
    val decision="1770000000,arcane_legends,combat,STABLE,1209600,1804800,650,\"CPU pacing, with commas\",40,60,SUCCESS,39,60,-1,0,-3,sd695,ACTIVE"
    val d=parseCsv(decision)
    requireEq("decision column count",d.size,18)
    requireEq("quoted comma",d[7],"CPU pacing, with commas")
    requireEq("decision outcome",d[10],"SUCCESS")
    val escaped="1,g,s,p,1,2,3,\"said \"\"hold\"\", then keep\",40,60,SUCCESS,39,60,0,0,0,h,ACTIVE"
    val e=parseCsv(escaped)
    requireEq("escaped quote",e[7],"said \"hold\", then keep")
    val plan="1770000000,HOLD,91,stable,ENVELOPE,STABLE,652800,1209600,806400,1804800,180,650"
    val p=parseCsv(plan)
    requireEq("plan column count",p.size,12)
    requireEq("plan profile",p[5],"STABLE")
    val now=1770000000L
    fun fresh(epoch:Long)=epoch>0 && (now-epoch) in 0..5
    requireEq("fresh current",fresh(now),true)
    requireEq("fresh 5s",fresh(now-5),true)
    requireEq("stale 6s",fresh(now-6),false)
    requireEq("future rejected",fresh(now+1),false)
    println("ALL REGRESSION TESTS PASSED")
}
