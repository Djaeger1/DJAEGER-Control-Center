#!/bin/sh
set -eu
D="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
TMP="${TMPDIR:-/tmp}/djaeger-control-center-regression.jar"
kotlinc "$D/ParserRegression.kt" -include-runtime -d "$TMP"
java -jar "$TMP"
rm -f "$TMP"
