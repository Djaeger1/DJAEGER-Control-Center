# DJAEGER Control Center v0.5.2 RC — Build Candidate Audit

## Corrections made after source re-audit
- Root stdout/stderr is drained concurrently while `su` is running, avoiding pipe back-pressure deadlock on larger log snapshots.
- Root command remains bounded by a 2.5 s timeout; the reader is cancelled and the process is forcibly terminated if needed.
- Telemetry freshness now requires age `0..5` seconds. Future timestamps are rejected instead of being treated as fresh.
- The installed DJAEGER module version is read from `module.prop` and surfaced in runtime state/UI.
- App metadata synchronized to versionCode 6 / versionName `0.5.2-rc-build-candidate`.

## Safety invariants
- Read-only shell payload: directory test, `cat`, `tail`, `sed`, `head`, `echo` only.
- No sysfs writes.
- No CPU/GPU control commands.
- No firewall/network/game traffic modification.
- No INTERNET permission.
- DJAEGER remains the sole hardware/thermal/restoration authority.

## Build status
Static source audit completed. APK compilation is not claimed: this runtime has Java/Kotlin but no Android SDK/Gradle toolchain, and outbound package download is unavailable.
