# DJAEGER Control Center v0.5.0 RC — Hardened Monitor

Companion Android monitor for DJAEGER Autonomous Control Plane v12.9.20 Mature Resource Intelligence.

## RC hardening
- Read-only architecture retained; no sysfs writes or game/network manipulation.
- Root command timeout (2.5 s) prevents a denied/hung `su` request from freezing refresh indefinitely.
- Refresh loop runs only while the Activity is STARTED and pauses in background.
- Telemetry samples are deduplicated by source epoch; stale/repeated rows no longer distort 60-second charts/statistics.
- CSV parser now handles quoted fields and escaped quotes in decision/plan history.
- Freshness flag separates a fresh telemetry sample from merely readable files.
- App version metadata synchronized to v0.5.0 RC.

## Scope
Monitoring only: runtime/session, telemetry, frame intelligence, Local AI state, adaptive envelope, Gemini state, decision/plan history, anomaly interpretation, safety/restoration visibility, and controller logs.

## Safety invariant
DJAEGER remains the sole hardware control authority. Gemini remains advisory. This app does not directly write CPU/GPU/sysfs state.
