package com.djaeger.gemini37chat;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String MODEL = "gemini-3.7-flash";
    private static final String ENDPOINT =
            "https://generativelanguage.googleapis.com/v1beta/models/" + MODEL + ":generateContent";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ArrayList<Turn> history = new ArrayList<>();

    private LinearLayout root;
    private LinearLayout messages;
    private ScrollView scroll;
    private EditText promptInput;
    private Button sendButton;
    private TextView statusText;
    private String apiKey = "";
    private boolean waiting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        apiKey = SecretStore.load(this);
        if (apiKey.isEmpty()) showKeyScreen(); else showChatScreen();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }

    private void baseScreen() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));
        root.setBackgroundColor(Color.rgb(17, 19, 24));
        setContentView(root);
    }

    private void showKeyScreen() {
        baseScreen();

        TextView title = text("Gemini 3.7 Chat", 28, Color.WHITE, true);
        root.addView(title);

        TextView model = text("Model: " + MODEL, 14, Color.rgb(160, 170, 185), false);
        LinearLayout.LayoutParams mp = wrap();
        mp.topMargin = dp(4);
        root.addView(model, mp);

        TextView help = text(
                "Masukkan Gemini API key. Key disimpan terenkripsi dengan Android Keystore dan tidak ditanam di APK.",
                15, Color.rgb(210, 215, 225), false);
        LinearLayout.LayoutParams hp = matchWrap();
        hp.topMargin = dp(28);
        root.addView(help, hp);

        final EditText keyInput = new EditText(this);
        keyInput.setTextColor(Color.WHITE);
        keyInput.setHintTextColor(Color.rgb(130, 140, 155));
        keyInput.setHint("AIza... / Gemini API key");
        keyInput.setSingleLine(true);
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyInput.setPadding(dp(14), 0, dp(14), 0);
        keyInput.setBackground(rounded(Color.rgb(35, 39, 48), 14));
        if (!apiKey.isEmpty()) keyInput.setText(apiKey);
        LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        kp.topMargin = dp(18);
        root.addView(keyInput, kp);

        Button save = new Button(this);
        save.setText("Simpan & Buka Chat");
        save.setTextColor(Color.WHITE);
        save.setAllCaps(false);
        save.setTextSize(16);
        save.setBackground(rounded(Color.rgb(86, 90, 230), 14));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        sp.topMargin = dp(14);
        root.addView(save, sp);

        statusText = text("", 13, Color.rgb(255, 180, 120), false);
        LinearLayout.LayoutParams stp = matchWrap();
        stp.topMargin = dp(12);
        root.addView(statusText, stp);

        save.setOnClickListener(v -> {
            String entered = keyInput.getText().toString().trim();
            if (entered.length() < 20) {
                statusText.setText("API key terlihat terlalu pendek.");
                return;
            }
            try {
                SecretStore.save(this, entered);
                apiKey = entered;
                showChatScreen();
            } catch (Exception e) {
                statusText.setText("Gagal menyimpan key dengan aman: " + e.getClass().getSimpleName());
            }
        });
    }

    private void showChatScreen() {
        baseScreen();

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Gemini 3.7 Chat", 21, Color.WHITE, true);
        TextView model = text(MODEL + " • thinking low", 12, Color.rgb(150, 160, 175), false);
        titles.addView(title);
        titles.addView(model);
        top.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button newChat = smallButton("Baru");
        Button keyButton = smallButton("Key");
        top.addView(newChat);
        LinearLayout.LayoutParams keyParams = new LinearLayout.LayoutParams(dp(70), dp(42));
        keyParams.leftMargin = dp(8);
        top.addView(keyButton, keyParams);
        root.addView(top, matchWrap());

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0, dp(14), 0, dp(14));
        scroll.addView(messages, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout composer = new LinearLayout(this);
        composer.setOrientation(LinearLayout.HORIZONTAL);
        composer.setGravity(Gravity.BOTTOM);

        promptInput = new EditText(this);
        promptInput.setTextColor(Color.WHITE);
        promptInput.setHintTextColor(Color.rgb(130, 140, 155));
        promptInput.setHint("Tulis pesan...");
        promptInput.setMinLines(1);
        promptInput.setMaxLines(5);
        promptInput.setImeOptions(EditorInfo.IME_ACTION_SEND);
        promptInput.setPadding(dp(14), dp(10), dp(14), dp(10));
        promptInput.setBackground(rounded(Color.rgb(35, 39, 48), 16));
        composer.addView(promptInput, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        sendButton = smallButton("Kirim");
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(dp(82), dp(50));
        sbp.leftMargin = dp(8);
        composer.addView(sendButton, sbp);
        root.addView(composer, matchWrap());

        statusText = text("Siap", 12, Color.rgb(150, 160, 175), false);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.topMargin = dp(7);
        root.addView(statusText, statusParams);

        if (history.isEmpty()) {
            addSystemNote("Masukkan pesan pertama. API key hanya dikirim ke Google sebagai header autentikasi.");
        } else {
            for (Turn turn : history) addBubble(turn.text, "user".equals(turn.role));
        }

        sendButton.setOnClickListener(v -> sendCurrentMessage());
        promptInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendCurrentMessage();
                return true;
            }
            return false;
        });

        newChat.setOnClickListener(v -> {
            if (waiting) return;
            history.clear();
            showChatScreen();
        });

        keyButton.setOnClickListener(v -> {
            if (waiting) return;
            showKeyScreen();
        });
    }

    private void sendCurrentMessage() {
        if (waiting) return;
        String prompt = promptInput.getText().toString().trim();
        if (prompt.isEmpty()) return;
        if (apiKey.isEmpty()) {
            showKeyScreen();
            return;
        }

        promptInput.setText("");
        addBubble(prompt, true);
        history.add(new Turn("user", prompt));
        setWaiting(true);

        executor.execute(() -> {
            try {
                String response = callGemini();
                history.add(new Turn("model", response));
                runOnUiThread(() -> {
                    addBubble(response, false);
                    setWaiting(false);
                    statusText.setText("Siap • " + MODEL);
                });
            } catch (Exception e) {
                if (!history.isEmpty() && "user".equals(history.get(history.size() - 1).role)) {
                    history.remove(history.size() - 1);
                }
                final String msg = friendlyError(e.getMessage());
                runOnUiThread(() -> {
                    addErrorBubble(msg);
                    setWaiting(false);
                    statusText.setText("Gagal mengirim");
                });
            }
        });
    }

    private String callGemini() throws Exception {
        JSONObject body = new JSONObject();
        JSONArray contents = new JSONArray();

        for (Turn turn : history) {
            JSONObject content = new JSONObject();
            content.put("role", turn.role);
            JSONArray parts = new JSONArray();
            JSONObject part = new JSONObject();
            part.put("text", turn.text);
            parts.put(part);
            content.put("parts", parts);
            contents.put(content);
        }
        body.put("contents", contents);

        JSONObject thinkingConfig = new JSONObject();
        thinkingConfig.put("thinkingLevel", "low");
        JSONObject generationConfig = new JSONObject();
        generationConfig.put("thinkingConfig", thinkingConfig);
        body.put("generationConfig", generationConfig);

        HttpURLConnection conn = (HttpURLConnection) new URL(ENDPOINT).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(90000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setRequestProperty("x-goog-api-key", apiKey);

        byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
        conn.setFixedLengthStreamingMode(payload.length);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(payload);
        }

        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String raw = readAll(stream);
        conn.disconnect();

        if (code < 200 || code >= 300) {
            String detail = extractApiError(raw);
            throw new Exception("HTTP " + code + (detail.isEmpty() ? "" : ": " + detail));
        }

        JSONObject json = new JSONObject(raw);
        JSONArray candidates = json.optJSONArray("candidates");
        if (candidates == null || candidates.length() == 0) {
            throw new Exception("Gemini tidak mengembalikan kandidat jawaban.");
        }

        JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
        if (content == null) throw new Exception("Respons Gemini tidak memiliki content.");
        JSONArray parts = content.optJSONArray("parts");
        if (parts == null) throw new Exception("Respons Gemini tidak memiliki parts.");

        StringBuilder answer = new StringBuilder();
        for (int i = 0; i < parts.length(); i++) {
            String t = parts.getJSONObject(i).optString("text", "");
            if (!t.isEmpty()) {
                if (answer.length() > 0) answer.append('\n');
                answer.append(t);
            }
        }
        if (answer.length() == 0) throw new Exception("Jawaban Gemini kosong.");
        return answer.toString().trim();
    }

    private String extractApiError(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        try {
            JSONObject error = new JSONObject(raw).optJSONObject("error");
            return error == null ? "" : error.optString("message", "");
        } catch (Exception ignored) {
            return "";
        }
    }

    private String friendlyError(String message) {
        if (message == null) return "Terjadi kesalahan jaringan.";
        if (message.contains("HTTP 400")) return "Permintaan ditolak. Periksa key dan akses model gemini-3.7-flash.\n" + message;
        if (message.contains("HTTP 401") || message.contains("HTTP 403")) return "API key tidak valid atau tidak punya izin.\n" + message;
        if (message.contains("HTTP 429")) return "Kuota/rate limit Gemini sedang tercapai. Coba lagi setelah kuota tersedia.\n" + message;
        return message;
    }

    private void setWaiting(boolean value) {
        waiting = value;
        sendButton.setEnabled(!value);
        promptInput.setEnabled(!value);
        statusText.setText(value ? "Gemini sedang berpikir…" : "Siap");
    }

    private void addBubble(String message, boolean user) {
        TextView bubble = text(message, 15, Color.WHITE, false);
        bubble.setTextIsSelectable(true);
        bubble.setPadding(dp(13), dp(10), dp(13), dp(10));
        bubble.setBackground(rounded(user ? Color.rgb(80, 84, 215) : Color.rgb(35, 39, 48), 16));

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.gravity = user ? Gravity.END : Gravity.START;
        p.topMargin = dp(8);
        p.leftMargin = user ? dp(46) : 0;
        p.rightMargin = user ? 0 : dp(46);
        messages.addView(bubble, p);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void addErrorBubble(String message) {
        TextView error = text("Error\n" + message, 14, Color.rgb(255, 215, 205), false);
        error.setTextIsSelectable(true);
        error.setPadding(dp(13), dp(10), dp(13), dp(10));
        error.setBackground(rounded(Color.rgb(92, 43, 43), 16));
        LinearLayout.LayoutParams p = wrap();
        p.topMargin = dp(8);
        p.rightMargin = dp(32);
        messages.addView(error, p);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void addSystemNote(String message) {
        TextView note = text(message, 13, Color.rgb(160, 170, 185), false);
        note.setGravity(Gravity.CENTER);
        note.setPadding(dp(8), dp(14), dp(8), dp(14));
        messages.addView(note, matchWrap());
    }

    private TextView text(String value, int sizeSp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setPadding(dp(6), 0, dp(6), 0);
        b.setBackground(rounded(Color.rgb(47, 51, 62), 12));
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(70), dp(42)));
        return b;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) out.append(line).append('\n');
        }
        return out.toString();
    }

    private static final class Turn {
        final String role;
        final String text;

        Turn(String role, String text) {
            this.role = role;
            this.text = text;
        }
    }
}
