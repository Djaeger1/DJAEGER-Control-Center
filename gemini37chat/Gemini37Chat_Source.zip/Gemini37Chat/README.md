# Gemini 3.7 Chat

Aplikasi Android native ringan untuk chat langsung ke Gemini API dengan model tetap `gemini-3.7-flash`.

## Fitur
- Masukkan API key sendiri dari aplikasi.
- API key disimpan terenkripsi menggunakan Android Keystore (AES/GCM).
- Model dikunci ke `gemini-3.7-flash`.
- Multi-turn chat: histori percakapan dikirim kembali ke Gemini.
- Thinking level `low` untuk respons lebih cepat/ringan.
- Tombol **Baru** untuk menghapus histori chat tanpa menghapus API key.
- Tombol **Key** untuk mengganti API key.
- Tidak memakai SDK pihak ketiga; request memakai HTTPS + `HttpURLConnection`.
- API key dikirim melalui header `x-goog-api-key`, bukan query URL.

## Build
1. Buka folder ini di Android Studio.
2. Biarkan Gradle sync selesai.
3. Build > Build APK(s).
4. APK debug muncul di `app/build/outputs/apk/debug/app-debug.apk`.

Konfigurasi: compileSdk 35, targetSdk 35, minSdk 23, Java 8.

## Catatan keamanan
API key tidak tertanam di source/APK. Key yang dimasukkan pengguna disimpan menggunakan Android Keystore. Pada perangkat yang di-root, perlindungan lokal tetap bergantung pada keamanan perangkat/ROM.
